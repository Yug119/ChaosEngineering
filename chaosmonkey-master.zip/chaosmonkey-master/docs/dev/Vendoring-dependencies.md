If you wish to add a new dependency to Chaos Monkey, use [govendor][1] to add it.

Please ensure that the license of the new dependency is compatible with Chaos Monkey's license: [Apache License Version 2.0][2].


[1]: https://github.com/kardianos/govendor
[2]: https://github.com/Netflix/chaosmonkey/blob/master/LICENSE